<div align="center">
    <img  width=180 src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/logo.png"/>
    <h1>✨Awesome Love Code✨<br>❤️表白代码收藏馆❤️</h1> 
</div>

> 部分代码源自于互联网，侵删！

# Web

<table align="center">
    <!-- 第一行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/001-sincere_heart">
            <p align="center">001-sincere_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/001.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/002-love_rose">
            <p align="center">002-love_rose</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/002.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/003-love_letter">
            <p align="center">003-love_letter</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/003.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第二行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/004-love_confession">
            <p align="center">004-love_confession</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/004.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/005-spoof_emoji">
            <p align="center">005-spoof_emoji</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/005.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/006-biubiu_heart">
            <p align="center">006-biubiu_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/006.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第三行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/007-3D_Album">
            <p align="center">007-3D_Album</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/007.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/008-cube_image">
            <p align="center">008-cube_image</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/008.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/009-fireworks_love">
            <p align="center">009-fireworks_love</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/009.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第四行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/010-words_drawer">
            <p align="center">010-words_drawer</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/010.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/011-neon_heart">
            <p align="center">011-neon_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/011.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/012-three_line">
            <p align="center">012-three_line</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/012.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第五行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/013-love_hourglass">
            <p align="center">013-love_hourglass</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/013.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/014-love_you">
            <p align="center">014-love_you</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/014.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/015-3D_Fireworks">
            <p align="center">015-3D_Fireworks</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/015.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第六行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/016-love_slideshow">
            <p align="center">016-love_slideshow</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/016.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/017-vscode_love">
            <p align="center">017-vscode_love</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/017.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/018-disguise_Baidu">
            <p align="center">018-disguise_Baidu</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/018.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第七行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/019-ribbon_word">
            <p align="center">019-ribbon_word</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/019.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/020-chat_mylove">
            <p align="center">020-chat_mylove</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/020.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/021-web_programmer">
            <p align="center">021-web_programmer</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/021.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第八行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/022-be_my_girlfrind">
            <p align="center">022-be_my_girlfrind</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/022.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/023-little_letter">
            <p align="center">023-little_letter</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/023.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/024-love_homepage">
            <p align="center">024-love_homepage</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/024.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第九行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/025-_520_loveu">
            <p align="center">025-_520_loveu</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/025.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/026-secret_letter">
            <p align="center">026-secret_letter</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/026.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/027-love_note">
            <p align="center">027-love_note</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/027.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第十行 -->
    <tr>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/028-i_love_you">
            <p align="center">028-i_love_you</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/028.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/029-my_valentines_day">
            <p align="center">029-Valentines_Day</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/029.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://sun0225sun.github.io/Awesome-Love-Code/Web/030-miss_you">
            <p align="center">030-miss_you</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/web/030.jpg"/>
        </a>
    </td>
    </tr>
</table>

# Python

<table align="center">
    <!-- 第一行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/001-be_my_girlfriend">
            <p align="center">001-be_my_girlfriend</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/001.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/002-one_line_love">
            <p align="center">002-one_line_love</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/002.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/003-send_love">
            <p align="center">003-send_love</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/003.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第二行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/004-flowers">
            <p align="center">004-flowers</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/004.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/005-3D_love">
            <p align="center">005-3D_love</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/005.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/Python/006-love_you">
            <p align="center">006-love_you</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/006.jpg"/>
        </a>
    </td>
    </tr>
</table>

# MatLab

<table align="center">
    <!-- 第一行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/001-just_heart">
            <p align="center">001-just_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/001.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/002-heart">
            <p align="center">002-heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/002.gif"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/003-heart_3d">
            <p align="center">003-heart_3d</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/003.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第二行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/004-my_heart">
            <p align="center">004-my_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/004.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/005-red_heart">
            <p align="center">005-red_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/005.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/006-love_heart">
            <p align="center">006-love_heart</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/006.jpg"/>
        </a>
    </td>
    </tr>
    <!-- 第三行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/007-rose">
            <p align="center">007-rose</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/007.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/008-roseBall">
            <p align="center">008-roseBall</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/008.jpg"/>
        </a>
    </td>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/MatLab/009-LoveFunc">
            <p align="center">009-LoveFunc</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/matlab/009.jpg"/>
        </a>
    </td>
    </tr>
</table>

# C#

<table align="center">
    <!-- 第一行 -->
    <tr>
    <td valign="top">
        <a href="https://github.com/sun0225SUN/Awesome-Love-Code/tree/main/csharp/001-be_my_girlfriend">
            <p align="center">001-be_my_girlfriend</p>
            <img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/csharp/001.gif"/>
        </a>
    </td>
    </tr>
</table>
