# 安装依赖

```
pip install turtle
```

# 运行

```
python 文件名.py
```

# 效果

![](./img/1.jpg)
