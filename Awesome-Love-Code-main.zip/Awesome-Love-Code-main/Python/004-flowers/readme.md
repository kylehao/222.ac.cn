# 安装所需库

```
pip install pillow
pip install matplotlib
pip install numpy
```

# 运行

```
python 文件名.py
```

![](./img/eg.png)

# 效果

![01](./img/01.png)

![02](./img/02.png)

![03](./img/03.png)

![04](./img/04.png)

![05](./img/05.png)
