# 执行

```shell
python index.py
```

# 效果

<img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/003.jpg"/>
