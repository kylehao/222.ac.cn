# 安装所需库

```
pip install matplotlib
pip install numpy
```

# 运行

```
python 文件名.py
```

![](./img/eg.jpg)

# 运行

```
python 文件名.py
```

![](./img/1.jpg)
