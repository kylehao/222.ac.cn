# 执行

```shell
$ python3 -m pip install pygame
$ cd be_my_girlfriend
$ python3 love.py
```

# 效果

<img src="https://cdn.jsdelivr.net/gh/sun0225SUN/Awesome-Love-Code/assets/img/python/001.jpg"/>
